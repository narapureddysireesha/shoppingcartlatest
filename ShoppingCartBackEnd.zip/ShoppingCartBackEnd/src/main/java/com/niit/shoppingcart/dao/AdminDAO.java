package com.niit.shoppingcart.dao;

import java.util.List;

import com.niit.shoppingcart.model.UserDetails;



public interface AdminDAO {


	public List<UserDetails> list();

	public UserDetails get(String id);

	public void saveOrUpdate(UserDetails user);

	public void delete(String id);
	
	public boolean isValidAdmin(String id, String password);


}
